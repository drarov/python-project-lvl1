#!/usr/bin/env python3

def main():
    from brain_games.gcd import start
    start()


if __name__ == '__main__':
    main()
