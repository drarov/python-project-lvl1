#!/usr/bin/env python3

def main():
    from brain_games.even import even_start
    even_start()


if __name__ == '__main__':
    main()
